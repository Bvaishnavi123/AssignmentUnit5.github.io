import { useState } from 'react'
import logo from './logo.svg'
import {FormData} from "./Components/form"
import './App.css'

function App() {
  

  return (
    <div className="App">
      <FormData/>
    </div>
  )
}

export default App
